﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json;

namespace CorreçãoCP01
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void lnkCadastrar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string json = File.ReadAllText("usuarios.json");

            var usuarios = JsonSerializer.Deserialize<List<Usuario>>(json);
                           
            var usuario = usuarios.FirstOrDefault(u => u.Email == txtEmail.Text && u.Senha == txtSenha.Text);

            if (usuario != null)
            {
                this.Hide();
                var formPrincipal = new CadastroUsuario();
                formPrincipal.ShowDialog();
                this.Close();
            }
            else
            {
                               MessageBox.Show("Email ou senha incorretos.");
            }
        }
    }
}
