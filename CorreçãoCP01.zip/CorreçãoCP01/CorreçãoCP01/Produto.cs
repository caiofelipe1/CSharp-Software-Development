﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CorreçãoCP01
{
    public class Produto
    {
        [JsonPropertyName("Nome")]
        public string Nome { get; set; }

        [JsonPropertyName("Categoria")]
        public string Categoria { get; set; }

        [JsonPropertyName("Preco")]
        public decimal Preco { get; set; }

        [JsonPropertyName("Quantidade")]
        public int Quantidade { get; set; }
    }
}
